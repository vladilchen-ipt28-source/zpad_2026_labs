#!/bin/bash
# Створюємо папку для збірки, якщо її немає
mkdir -p build
cd build
# Генеруємо файли збірки та компілюємо
cmake ..
make