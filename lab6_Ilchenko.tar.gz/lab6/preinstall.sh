#!/bin/bash
# Оновлюємо список пакетів та встановлюємо необхідне
sudo apt update
sudo apt install -y build-essential cmake libopencv-dev g++