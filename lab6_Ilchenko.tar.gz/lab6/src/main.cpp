#include <opencv2/opencv.hpp>
#include "../include/CameraProvider.hpp"
#include "../include/KeyProcessor.hpp"
#include "../include/FrameProcessor.hpp"

// Функція для мишки
void onMouse(int event, int x, int y, int flags, void* userdata) {
    FrameProcessor* processor = (FrameProcessor*)userdata;
    if (event == cv::EVENT_LBUTTONDOWN) {
        processor->setDrawing(true);
        processor->setMousePoint(cv::Point(x, y));
    } else if (event == cv::EVENT_LBUTTONUP) {
        processor->setDrawing(false);
    } else if (event == cv::EVENT_MOUSEMOVE && (flags & cv::EVENT_FLAG_LBUTTON)) {
        processor->setMousePoint(cv::Point(x, y));
    }
}

int main() {
    CameraProvider camera("/home/vlad/Desktop/lab6/video.mp4"); 
    KeyProcessor keyHandler;
    FrameProcessor frameProcessor;

    if (!camera.isOpened()) {
        std::cerr << "Камеру не знайдено!" << std::endl;
        return -1;
    }

    cv::namedWindow("Lab 6 - OpenCV App");
    cv::setMouseCallback("Lab 6 - OpenCV App", onMouse, &frameProcessor);

    while (true) {
        cv::Mat frame = camera.getFrame();
        if (frame.empty()) break;

        // Обробка режимів
        frameProcessor.process(frame, keyHandler.getMode());

        cv::imshow("Lab 6 - OpenCV App", frame);

        int key = cv::waitKey(30);
        if (key == 27) break; // ESC для виходу
        keyHandler.processKey(key);
    }

    return 0;
}
