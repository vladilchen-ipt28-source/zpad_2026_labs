#!/bin/bash
# Запуск виконуваного файлу з папки build
./build/lab6_app