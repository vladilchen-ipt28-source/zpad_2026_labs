#ifndef KEY_PROCESSOR_HPP
#define KEY_PROCESSOR_HPP

// Перелік режимів для лаби
enum class Mode { ORIGINAL, CANNY, BLUR, INVERT, GLITCH };

class KeyProcessor {
public:
    KeyProcessor() : currentMode(Mode::ORIGINAL) {}

    void processKey(int key) {
        if (key == '1') currentMode = Mode::ORIGINAL;
        else if (key == '2') currentMode = Mode::CANNY;
        else if (key == '3') currentMode = Mode::BLUR;
        else if (key == '4') currentMode = Mode::INVERT;
        else if (key == '5') currentMode = Mode::GLITCH;
    }

    Mode getMode() const { return currentMode; }

private:
    Mode currentMode;
};

#endif