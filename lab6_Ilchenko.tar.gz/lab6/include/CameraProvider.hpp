#ifndef CAMERA_PROVIDER_HPP
#define CAMERA_PROVIDER_HPP

#include <opencv2/opencv.hpp>
#include <string>

class CameraProvider {
public:
    // Конструктор приймає або "0" для камери, або шлях до файлу
    CameraProvider(std::string source = "0") {
        if (source == "0") {
            cap.open(0);
        } else {
            cap.open(source);
        }
    }
    
    ~CameraProvider() { if (cap.isOpened()) cap.release(); }
    
    cv::Mat getFrame() {
        cv::Mat frame;
        cap >> frame;
        // Якщо відео закінчилося, повертаємо на початок (loop)
        if (frame.empty() && cap.get(cv::CAP_PROP_FRAME_COUNT) > 0) {
            cap.set(cv::CAP_PROP_POS_FRAMES, 0);
            cap >> frame;
        }
        return frame;
    }
    
    bool isOpened() const { return cap.isOpened(); }

private:
    cv::VideoCapture cap;
};

#endif
