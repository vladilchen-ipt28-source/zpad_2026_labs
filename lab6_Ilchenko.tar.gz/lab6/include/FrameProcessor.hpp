#ifndef FRAME_PROCESSOR_HPP
#define FRAME_PROCESSOR_HPP

#include <opencv2/opencv.hpp>
#include "KeyProcessor.hpp"

class FrameProcessor {
public:
    FrameProcessor() : mousePoint(-1, -1), isDrawing(false) {}

    void process(cv::Mat& frame, Mode mode) {
        if (frame.empty()) return;

        // Вибір фільтра
        if (mode == Mode::CANNY) {
            cv::cvtColor(frame, frame, cv::COLOR_BGR2GRAY);
            cv::Canny(frame, frame, 100, 200);
            cv::cvtColor(frame, frame, cv::COLOR_GRAY2BGR);
        } 
        else if (mode == Mode::BLUR) {
            cv::GaussianBlur(frame, frame, cv::Size(15, 15), 0);
        }
        else if (mode == Mode::INVERT) {
            cv::bitwise_not(frame, frame);
        }

        // Малювання мишкою (вимога лаби)
        if (isDrawing && mousePoint.x != -1) {
            cv::circle(frame, mousePoint, 20, cv::Scalar(0, 255, 0), -1);
        }
        
        // Текст на екрані
        cv::putText(frame, "Press 1-5 to change mode", cv::Point(10, 30), 
                    cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(255, 255, 255), 2);
    }

    void setMousePoint(cv::Point p) { mousePoint = p; }
    void setDrawing(bool d) { isDrawing = d; }

private:
    cv::Point mousePoint;
    bool isDrawing;
};

#endif